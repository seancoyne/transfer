package com.compoundtheory.objectcache;

import java.util.*;
import java.lang.ref.*;

/**
 * Class that wraps an object that is being cached
 * and provide meta data information about it's
 * cached state
 * 
 * @author Mark Mandel
 */

public class CachedObject {
	
	//number of times the object has been accessed
	private int hits; 
	//the date it was created
	private Date created;
	//object expiry date
	private Date expired;
	//soft ref to cfc
	private SoftReference cfcSoftRef;
	
	
	//use this when not expiring, 10 years should be long enough
	private static final int SECONDS_IN_10_YEARS = (60 * 60 * 24 * 364 * 10);
	
	/** 
	 * sets up an empty cached object
	 */
	public CachedObject()
	{
		clean();
	}
	
	/**
	 * Configures this instance of the CachedObject
	 * @param softRef The soft reference that contains the CFC
	 * @param secondsPersisted The number of seconds to persist the object
	 */
	public void configure(SoftReference softRef, int secondsPersisted)
	{
		setHits(0);
		setCreated(new Date());
		
		setCfcSoftRef(softRef);
		
		//calculate expired value
		Calendar expired = Calendar.getInstance();
		
		if(secondsPersisted > Config.UNLIMITED_SECONDS)
		{
			expired.add(Calendar.SECOND, secondsPersisted);
		}
		else
		{
			expired.add(Calendar.SECOND, SECONDS_IN_10_YEARS);
		}
		
		setExpired(expired.getTime());
	}
	
	/**
	 * Sets all references to null,
	 * release the variables
	 */
	public void clean()
	{
		setHits(-1);
		setCreated(null);
		setExpired(null);
		setCfcSoftRef(null);
	}
	

	/**getCachedObjectPool().getCachedObject();
	 * Retrieve the identity hash code for the object
	 * @return the hashcode
	 */
	/*
	public int getObjectIdentityHashCode()
	{
		return System.identityHashCode(getCFC());
	}
	*/
	
	/**
	 * Is the object being persisted equal to another object
	 * @param object the object being persisted
	 * @return true or false
	 */
	/*
	public boolean isObjectEqual(Object object)
	{
		return System.identityHashCode(object) == getObjectIdentityHashCode();
	}
	*/
	
	/**
	 * Calculates the fitness of this
	 * object being persisted in the 
	 * pool
	 * @return the fitness of the object
	 */
	public int calculateFitness()
	{
		int fitness = getHits();
		
		//catch a possible clean() object
		if(fitness == -1)
		{
			return 0;
		}
		
		/**
		 * gives the object extra fitness for how new it
		 * is for the first hour, then it's on it's own
		 */
		
		int minutes = Math.round(((new Date()).getTime() - getCreated().getTime()) / (1000 * 60));
		
		if(minutes < 60)
		{
			fitness += (60 - minutes);
		}

		return fitness;
	}
	
	/**
	 * Has the cached object expired?
	 * @return if it has expired
	 */
	public boolean hasExpired()
	{
		//if this has been attempted to be expired more than once.
		if(getExpired() == null)
		{
			return true;
		}
		
		Date now = new Date();
		return now.after(getExpired());
	}
	
	public Date getCreated()
	{
		return created;
	}

	private void setCreated(Date created)
	{
		this.created = created;
	}

	public int getHits()
	{
		return hits;
	}
	
	private void setHits(int hits)
	{
		this.hits = hits;
	}
	
	/**
	 * Increment this every time the object is 
	 * grabbed from the cache
	 */
	public void incrementHits()
	{
		setHits(getHits() + 1);
	}

	public Object getCFC()
	{
		return getCfcSoftRef().get();
	}
	
	public SoftReference getCfcSoftRef()
	{
		return cfcSoftRef;
	}

	private void setCfcSoftRef(SoftReference cfcSoftRef)
	{
		this.cfcSoftRef = cfcSoftRef;
	}

	public Date getExpired()
	{
		return expired;
	}

	private void setExpired(Date expired)
	{
		this.expired = expired;
	}

}
