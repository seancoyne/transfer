package com.compoundtheory.objectcache;

/**
 * Exception that is thrown when a scope is set to an
 * invalid value
 * 
 * @author Mark Mandel
 */
public class InvalidScopeException extends Exception
{
	private static final long serialVersionUID = 1150128745531472294L;

	/**
	 * Default constructor. Has the message 'Object not found'
	 */
	public InvalidScopeException()
	{
		super("Invalid Scope selected");
	}
	
	/**
	 * ObjectNotFound exception with a mesasge
	 * @param msg
	 */
	public InvalidScopeException(String msg)
	{
		super(msg);
	}
}
