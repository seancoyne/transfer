package com.compoundtheory.objectcache;

import java.lang.ref.SoftReference;
import java.util.*;
import org.apache.commons.collections.*;
import edu.emory.mathcs.backport.java.util.concurrent.*;

/**
 * This is a cache manager for a set 
 * of classes
 * @author Mark Mandel
 */
public class CacheManager implements Observer, ICacheManager
{
	private CacheConfig config;
	private Buffer discardQueue;
	private Map cacheCollection;
	private ThreadPoolExecutor threadPool; 
	
	/**
	 * Constructor, requires the config object
	 * @param config The config object that defines the caching settings for each class  
	 */
	public CacheManager(CacheConfig config, ThreadPoolExecutor threadPool)
	{
		setConfig(config);
		setThreadPool(threadPool);
		setDiscardQueue(BufferUtils.synchronizedBuffer(new UnboundedFifoBuffer()));
		setCacheCollection(Collections.synchronizedMap(new HashMap()));
	}
	
	/**
	 * Update to be called for Observer/Observable.
	 * Puts the Object into the discard queue
	 */
	public void update(Observable observable, Object object)
	{
		//add the object to the discard queue, if it is in there
		if(!discardQueueContainsCFC(object))
		{
			getDiscardQueue().add(object);
		}
	}
	
	private boolean discardQueueContainsCFC(Object cfc)
	{
		Iterator iterator = getDiscardQueue().iterator();
		
		try
		{
			while(iterator.hasNext())
			{
				if(System.identityHashCode(iterator.next()) == System.identityHashCode(cfc))
				{
					return true;
				}
			}			
		}
		catch(NoSuchElementException exc)
		{
			//don't care anymore
		}
		return false;
	}
	
	
	/**
	 * Pops a CFC off the Discard Queue,  
	 * @return The CFC that was poped
	 */
	public Object popFromDiscardQueue()
	{
		return getDiscardQueue().remove();
	}
	
	/**
	 * If the DiscardQueue is empty or not
	 * @return If the queue is empty
	 */
	public boolean discardQueueIsEmpty()
	{
		return getDiscardQueue().isEmpty();
	}
	
	/**
	 * How many objects are in the discard queue
	 * @return the size() of the discard queue
	 */
	public int discardQueueSize()
	{
		return getDiscardQueue().size();
	}
	
	/**
	 * Whether the CFC has been cached
	 * @param clazz The class of CFC
	 * @param key The key the CFC is stored under
	 * @return If it exists in a cache
	 */
	public boolean has(String clazz, String key)
	{
		return retrieveObjectCache(clazz).has(key);
	}
	
	/**
	 * Retrieve a CFC from the cache
	 * @param clazz The class of the CFC
	 * @param key The key it was stored under
	 * @return The CFC itself
	 * @throws ObjectNotFoundException if the object doesn't exist in the cache
	 */
	public Object get(String clazz, String key)
	throws ObjectNotFoundException
	{
		return retrieveObjectCache(clazz).get(key);
	}
	
	/**
	 * Adds an object to to the cache
	 * @param clazz The class of the object
	 * @param key The key of the object
	 * @param softRef The soft reference containing the CFC
	 */
	public void add(String clazz, String key, SoftReference softRef)
	{
		retrieveObjectCache(clazz).add(softRef, key);
	}
	
	/**
	 * Discard the object from the cache
	 * @param clazz the class of the object
	 * @param key the key of the object to discard
	 */
	public void discard(String clazz, String key)
	{
		retrieveObjectCache(clazz).discard(key);
	}
	
	/**
	 * Reap off a cleared soft reference
	 * @param clazz the class to reap to
	 * @param softRef the soft reference to reap
	 */
	public void reap(String clazz, SoftReference softRef)
	{
		retrieveObjectCache(clazz).reap(softRef);
	}
	
	/**
	 * Attempts to find a Cached object for the class
	 * and if it can find it, return it, otherwise,
	 * creates a new one
	 * @return The CachedObject for the class
	 */
	private ObjectCache retrieveObjectCache(String clazz)
	{
		if(!getCacheCollection().containsKey(clazz))
		{
			createObjectCache(clazz);
		}
		
		return (ObjectCache) getCacheCollection().get(clazz);
	}
	
	/**
	 * Synchronised creation to avoid thread issues
	 * @param clazz the class for the Cached Objects
	 */
	private synchronized void createObjectCache(String clazz)
	{
		//double check it
		if(!getCacheCollection().containsKey(clazz))
		{
			Config config = getConfig().getConfig(clazz); 
			ObjectCache cache = new ObjectCache(clazz, getThreadPool(), config.getMaxObjects(), config.getSecondsPersisted());
			
			//add observer
			cache.addObserver(this);
			
			getCacheCollection().put(clazz, cache);			
		}
	}
	
	private CacheConfig getConfig()
	{
		return config;
	}

	private void setConfig(CacheConfig config)
	{
		this.config = config;
	}

	private Buffer getDiscardQueue()
	{
		return discardQueue;
	}

	private void setDiscardQueue(Buffer discardQueue)
	{
		this.discardQueue = discardQueue;
	}

	private Map getCacheCollection()
	{
		return cacheCollection;
	}

	private void setCacheCollection(Map cacheCollection)
	{
		this.cacheCollection = cacheCollection;
	}

	private ThreadPoolExecutor getThreadPool() {
		return threadPool;
	}

	private void setThreadPool(ThreadPoolExecutor threadPool) {
		this.threadPool = threadPool;
	}
	
}
