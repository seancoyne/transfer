package com.compoundtheory.dynamic;

import java.util.*;

/**
 * Builds the tree structure for building mementos for TransferObject population
 * 
 * @author mark
 * 
 */

public class Memento
{
	private Map valueMap;
	private Map children;

	private static String KEY_ISARRAY = "isArray";
	private static String KEY_COLLECTION = "collection";

	/**
	 * Constructor
	 * 
	 * @param valueMap
	 *            The map of values for this memento part
	 */
	public Memento(Map valueMap)
	{
		setValueMap(valueMap);
		setChildren(new HashMap());
	}

	/**
	 * Adds a child set of values to this memento
	 * 
	 * @param compositeName
	 *            The name of the composite structure
	 * @param isArray
	 *            if it is an array or not
	 * @param child
	 *            The child to add
	 */
	public void addChild(String compositeName, Boolean isArray, Memento child)
	{
		Map position;

		// create a collection of children, based off the composition name
		if (getChildren().containsKey(compositeName))
		{
			position = (Map) getChildren().get(compositeName);
		}
		else
		{
			position = new HashMap();

			position.put(KEY_ISARRAY, isArray);
			position.put(KEY_COLLECTION, new ArrayList());

			getChildren().put(compositeName, position);
		}

		((List) position.get(KEY_COLLECTION)).add(child);
	}

	/**
	 * Returns the map value of this memento and its children
	 * 
	 * @return Map the memento map
	 */
	public Map getMemento()
	{
		return getMemento(new HashMap());
	}
	
	public Map getMemento(Map localCache)
	{
		Map memento = new HashMap(getChildren().size());

		if(!localCache.containsKey(this))
		{
			localCache.put(this, memento);
		}
		else
		{
			return (Map)localCache.get(this);
		}
		
		// shift all the memento values across
		memento.putAll(getValueMap());

		Iterator keyIterator = getChildren().keySet().iterator();

		// loop around the composition names
		while (keyIterator.hasNext())
		{
			// this is a string, but we don't actually care.
			Object key = keyIterator.next();

			Map position = (Map) getChildren().get(key);

			Iterator childIterator = ((List) position.get(KEY_COLLECTION))
					.iterator();

			// loop around the children
			while (childIterator.hasNext())
			{
				Memento child = (Memento) childIterator.next();

				// if we're an array, make one
				if (((Boolean) position.get(KEY_ISARRAY)).booleanValue())
				{
					if (!memento.containsKey(key))
					{
						memento.put(key, new ArrayList());
					}

					((List) memento.get(key)).add(child.getMemento(localCache));
				}
				else
				// otherwise, just drop it in
				{
					memento.put(key, child.getMemento(localCache));
				}
			}
		}

		return memento;		
	}

	private Map getValueMap()
	{
		return valueMap;
	}

	private void setValueMap(Map valueMap)
	{
		this.valueMap = valueMap;
	}

	private Map getChildren()
	{
		return children;
	}

	private void setChildren(Map children)
	{
		this.children = children;
	}
}
