package com.compoundtheory.objectcache;

import java.lang.ref.SoftReference;
import java.util.Set;

public interface ICacheManager
{
	/**
	 * Whether the CFC has been cached
	 * @param clazz The class of CFC
	 * @param key The key the CFC is stored under
	 * @return If it exists in a cache
	 */
	public boolean has(String clazz, String key);

	/**
	 * Retrieve a CFC from the cache
	 * @param clazz The clas of the CFC
	 * @param key The key it was stored under
	 * @return The CFC itself
	 * @throws ObjectNotFoundException if the object doesn't exist in the cache
	 */
	public Object get(String clazz, String key)
			throws ObjectNotFoundException;

	/**
	 * Adds an object to to the cache
	 * @param clazz The class of the object
	 * @param key The key of the object
	 * @param softRef The soft reference containing the CFC
	 */
	public void add(String clazz, String key, SoftReference softRef);

	/**
	 * Discard the object from the cache
	 * @param clazz the class of the object
	 * @param key the key to discard
	 */
	public void discard(String clazz, String key);
	
	/**
	 * Reap off a cleared soft reference
	 * @param clazz the class to reap to
	 * @param softRef the soft reference to reap
	 */	
	public void reap(String clazz, SoftReference softRef);
	
	
	/**
	 * remove a soft reference cleared object from the map
	 * so it can be fired for a discard queue
	 * 
	 * @param softRef the softreference to be cleared
	 */
	public Object popReapedCFC(SoftReference softRef);
	
	/**
	 * gets the set of classes that are stored in this
	 * cache
	 * @return Set of classnames that are stored in this cache.
	 */
	public Set getCachedClasses();	

}