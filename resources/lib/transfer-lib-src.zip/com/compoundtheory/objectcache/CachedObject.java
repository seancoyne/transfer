package com.compoundtheory.objectcache;

import java.util.*;
import java.lang.ref.*;

/**
 * Class that wraps an object that is being cached
 * and provide meta data information about it's
 * cached state
 * 
 * @author Mark Mandel
 */

public class CachedObject {
	
	//number of times the object has been accessed
	private int hits; 
	//the date it was created
	private Date created;
	//object expiry date
	private Date expired;
	
	private Date lastHit;
	
	private int secondsAccessedTimeout;
	
	//soft ref to cfc
	private SoftReference cfcSoftRef;

	
	//use this when not expiring, 10 years should be long enough
	private static final int SECONDS_IN_10_YEARS = (60 * 60 * 24 * 364 * 10);
	
	/** 
	 * sets up an empty cached object
	 * @param softRef The soft reference that contains the CFC
	 * @param secondsPersisted The number of seconds to persist the object	 * 
	 */
	public CachedObject(SoftReference softRef, int secondsPersisted, int secondsAccessedTimeout)
        {
	    setHits(0);
	    setCreated(new Date());
	    setSecondsAccessedTimeout(secondsAccessedTimeout);
	    setCfcSoftRef(softRef);
        
	    // calculate expired value
	    Calendar expired = Calendar.getInstance();
        
	    if (secondsPersisted > Config.UNLIMITED_SECONDS)
	    {
		expired.add(Calendar.SECOND, secondsPersisted);
	    } 
	    else
	    {
		expired.add(Calendar.SECOND, SECONDS_IN_10_YEARS);
	    }
        
	    setExpired(expired.getTime());
        
	    // handles the conditionals for us
	    incrementLastHit();
        }
    	
	/*
	 * clears any references this object has and enQueues
	 * the soft reference
	 */
	public void clear()
	{
		SoftReference softReference = getCfcSoftRef();
		
		//empty the soft ref, and push it onto the queue
		softReference.clear();
		
		if(!softReference.isEnqueued())
		{
		    softReference.enqueue();
		}		
	}
	
	/**
	 * Calculates the fitness of this
	 * object being persisted in the 
	 * pool
	 * @return the fitness of the object
	 */
	public int calculateFitness()
	{
		int fitness = getHits();
		
		//catch a possible clean() object
		if(fitness == -1)
		{
			return 0;
		}
		
		/**
		 * gives the object extra fitness for how new it
		 * is for the first hour, then it's on it's own
		 */
		
		int minutes = Math.round(((new Date()).getTime() - getCreated().getTime()) / (1000 * 60));
		
		if(minutes < 60)
		{
			fitness += (60 - minutes);
		}

		return fitness;
	}
	
	/**
	 * Hit to cached object
	 */
	public void hit()
	{
	    incrementHits();
	    incrementLastHit();
	}
	
	/**
	 * Increments the last hit value
	 */
	private void incrementLastHit()
	{
	    if(getSecondsAccessedTimeout() > Config.NONE_TIMEOUT)
	    {
		Calendar timeout = Calendar.getInstance();
		timeout.add(Calendar.SECOND, getSecondsAccessedTimeout());
		
		setLastHit(timeout.getTime());
	    }
	}
	
	/**
	 * Has the cached object expired?
	 * @return if it has expired
	 */
	public boolean hasExpired()
	{
		//if this has been attempted to be expired more than once.
		if(getExpired() == null)
		{
			return true;
		}
		
		Date now = new Date();
		
		//check for last hit expiration
		if(getSecondsAccessedTimeout() > Config.NONE_TIMEOUT)
		{
		    if(now.after(getLastHit()))
		    {
			return true;
		    }
		}
		
		return now.after(getExpired());
	}
	
	public Date getCreated()
	{
		return created;
	}

	private void setCreated(Date created)
	{
		this.created = created;
	}

	public int getHits()
	{
		return hits;
	}
	
	private void setHits(int hits)
	{
		this.hits = hits;
	}
	
	/**
	 * Increment this every time the object is 
	 * grabbed from the cache
	 */
	private void incrementHits()
	{
		setHits(getHits() + 1);
	}

	public Object getCFC()
	{
		return getCfcSoftRef().get();
	}
	
	public SoftReference getCfcSoftRef()
	{
		return cfcSoftRef;
	}

	private void setCfcSoftRef(SoftReference cfcSoftRef)
	{
		this.cfcSoftRef = cfcSoftRef;
	}

	public Date getExpired()
	{
		return expired;
	}

	private void setExpired(Date expired)
	{
		this.expired = expired;
	}

	private Date getLastHit()
	{
	    return lastHit;
	}

	private void setLastHit(Date lastHit)
	{
	    this.lastHit = lastHit;
	}

	private int getSecondsAccessedTimeout()
	{
	    return secondsAccessedTimeout;
	}

	private void setSecondsAccessedTimeout(int secondsAccessedTimeout)
	{
	    this.secondsAccessedTimeout = secondsAccessedTimeout;
	}
}
