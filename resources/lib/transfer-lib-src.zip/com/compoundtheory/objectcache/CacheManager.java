package com.compoundtheory.objectcache;

import java.lang.ref.SoftReference;
import java.util.*;

import edu.emory.mathcs.backport.java.util.concurrent.*;

/**
 * This is a cache manager for a set of classes
 * 
 * @author Mark Mandel
 */
public class CacheManager implements ICacheManager, Observer
{
    private CacheConfig config;
    private Map cacheCollection;
    private Map reapMap;
    private ThreadPoolExecutor threadPool;

    /**
     * Constructor, requires the config object
     * 
     * @param config
     *            The config object that defines the caching settings for each
     *            class
     */
    public CacheManager(CacheConfig config, ThreadPoolExecutor threadPool)
    {
	setConfig(config);
	setThreadPool(threadPool);
	setCacheCollection(Collections.synchronizedMap(new HashMap()));
	setReapMap(Collections.synchronizedMap(new HashMap()));
    }

    /**
     * Whether the CFC has been cached
     * 
     * @param clazz
     *            The class of CFC
     * @param key
     *            The key the CFC is stored under
     * @return If it exists in a cache
     */
    public boolean has(String clazz, String key)
    {
	return retrieveObjectCache(clazz).has(key);
    }

    /**
     * Retrieve a CFC from the cache
     * 
     * @param clazz
     *            The class of the CFC
     * @param key
     *            The key it was stored under
     * @return The CFC itself
     * @throws ObjectNotFoundException
     *             if the object doesn't exist in the cache
     */
    public Object get(String clazz, String key) throws ObjectNotFoundException
    {
	return retrieveObjectCache(clazz).get(key);
    }

    /**
     * Adds an object to to the cache
     * 
     * @param clazz
     *            The class of the object
     * @param key
     *            The key of the object
     * @param softRef
     *            The soft reference containing the CFC
     */
    public void add(String clazz, String key, SoftReference softRef)
    {
	retrieveObjectCache(clazz).add(softRef, key);
    }

    /**
     * Discard the object from the cache
     * 
     * @param clazz
     *            the class of the object
     * @param key
     *            the key of the object to discard
     */
    public void discard(String clazz, String key)
    {
	retrieveObjectCache(clazz).discard(key);
    }

    /**
     * Reap off a cleared soft reference
     * 
     * @param clazz
     *            the class to reap to
     * @param softRef
     *            the soft reference to reap
     */
    public void reap(String clazz, SoftReference softRef)
    {
	retrieveObjectCache(clazz).reap(softRef);
    }

    /**
     * gets the set of classes that are stored in this cache
     * 
     * @return Set of classnames that are stored in this cache.
     */
    public Set getCachedClasses()
    {
	return getCacheCollection().keySet();
    }
    
    /**
     * Returns the calculated size (slow), by
     * looping through a copy of the collection and checking
     * if the soft references are cleared or not
     * 
     * @param clazz the class to get the size for
     * @return the calculated cache size
     */
    public int getCalculatedSize(String clazz)
    {
	if(getCacheCollection().containsKey(clazz))
	{
	    return ((ObjectCache)getCacheCollection().get(clazz)).getCalculatedSize(); 
	}
	
	return 0;
    }
    
    /**
     * Returns the estimate size of the cache (fast),
     * does not scan the cache for empty soft references
     * 
     * @param clazz the class to get the size for
     * @return the estimated cache size
     */
    public int getEstimatedSize(String clazz)
    {
	if(getCacheCollection().containsKey(clazz))
	{
	    return ((ObjectCache)getCacheCollection().get(clazz)).getEstimatedSize(); 
	}
	
	return 0;	
    }
    
    /**
     * Attempts to find a Cached object for the class and if it can find it,
     * return it, otherwise, creates a new one
     * 
     * @return The CachedObject for the class
     */
    private ObjectCache retrieveObjectCache(String clazz)
    {
	if (!getCacheCollection().containsKey(clazz))
	{
	    createObjectCache(clazz);
	}

	return (ObjectCache) getCacheCollection().get(clazz);
    }

    /**
     * Synchronised creation to avoid thread issues
     * 
     * @param clazz
     *            the class for the Cached Objects
     */
    private synchronized void createObjectCache(String clazz)
    {
	// double check it
	if (!getCacheCollection().containsKey(clazz))
	{
	    Config config = getConfig().getConfig(clazz);
	    ObjectCache cache = new ObjectCache(clazz, getThreadPool(), config);

	    cache.addObserver(this);
	    getCacheCollection().put(clazz, cache);
	}
    }

    /**
     * Push the cfc onto the reap map
     */
    public void update(Observable o, Object arg)
    {
	HashMap result = (HashMap) arg;
	Object cfc = result.get(ObjectCache.CLEAR_CFC_KEY);
	SoftReference softRef = (SoftReference) result.get(ObjectCache.CLEAR_SOFTREF_KEY);

	getReapMap().put(softRef, cfc);
    }

    /**
     * remove a soft reference cleared object from the map so it can be fired
     * for a discard queue
     * 
     * @param softRef
     *            the softreference to be cleared
     */
    public Object popReapedCFC(SoftReference softRef)
    {
	Object object = getReapMap().get(softRef);
	getReapMap().remove(softRef);

	return object;
    }

    private CacheConfig getConfig()
    {
	return config;
    }

    private void setConfig(CacheConfig config)
    {
	this.config = config;
    }

    private Map getCacheCollection()
    {
	return cacheCollection;
    }

    private void setCacheCollection(Map cacheCollection)
    {
	this.cacheCollection = cacheCollection;
    }

    private ThreadPoolExecutor getThreadPool()
    {
	return threadPool;
    }

    private void setThreadPool(ThreadPoolExecutor threadPool)
    {
	this.threadPool = threadPool;
    }

    private Map getReapMap()
    {
	return reapMap;
    }

    private void setReapMap(Map reapMap)
    {
	this.reapMap = reapMap;
    }

}
